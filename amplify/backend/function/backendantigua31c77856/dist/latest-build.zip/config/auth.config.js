module.exports = {
    secret : 'Secret-Key-Value',
    jwtExpiration : 3600,
    jwtRefreshExpiration : 86400,
};
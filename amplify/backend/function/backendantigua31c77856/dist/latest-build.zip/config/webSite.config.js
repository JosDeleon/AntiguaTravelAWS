module.exports = {
    webURL : 'https://main.d2fk9zj96sg3it.amplifyapp.com'
}